let menu = document.getElementById("menu")
let navbar = document.getElementById("navbar-links")
menu.addEventListener("click", () => {
    navbar.classList.toggle("activemenu")

    menu.classList.toggle("fa-xmark")


})